<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Belanja Online</title>
</head>
<body>

<div class="container mt-4">
    <div class="row">
        <!-- Form Belanja Online -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Belanja Online</h2>
                    <form action="#" method="post">
                        <div class="form-group">
                            <label for="customer">Customer</label>
                            <input type="text" class="form-control" id="customer" name="customer" required>
                        </div>
                        <div class="form-group">
                            <label>Pilih Produk</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="produk" id="tv" value="TV" checked>
                                <label class="form-check-label" for="tv">TV</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="produk" id="kulkas" value="Kulkas">
                                <label class="form-check-label" for="kulkas">Kulkas</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="produk" id="mesincuci" value="Mesin Cuci">
                                <label class="form-check-label" for="mesincuci">Mesin Cuci</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="jumlah">Jumlah</label>
                            <input type="text" class="form-control" id="jumlah" name="jumlah" required>
                        </div>
                        <button type="submit" class="btn btn-success">Kirim</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Daftar Harga -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-body bg-primary text-white">
                    <h5 class="card-title">Daftar Harga</h5>
                </div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">TV : 4.200.000</li>
                    <li class="list-group-item">Kulkas : 3.100.000</li>
                    <li class="list-group-item">MESIN CUCI : 3.800.000</li>
                </ul>
                <div class="card-footer bg-primary text-white">
                    <h5>Harga Dapat Berubah Setiap Saat</h5>
                </div>
            </div>
        </div>
    </div>

    <!-- Hasil Form -->
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Hasil</h4>
                    <p>Nama Customer: <?php echo isset($_POST['customer']) ? $_POST['customer'] : ''; ?></p>
                    <p>Produk Pilihan: <?php echo isset($_POST['produk']) ? $_POST['produk'] : ''; ?></p>
                    <p>Jumlah Beli: <?php echo isset($_POST['jumlah']) ? $_POST['jumlah'] : ''; ?></p>
                    <p>Total Belanja: <?php echo calculateTotal(); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>

<?php
function calculateTotal() {
    if (isset($_POST['produk']) && isset($_POST['jumlah'])) {
        $hargaProduk = 0;

        switch ($_POST['produk']) {
            case 'TV':
                $hargaProduk = 4200000;
                break;
            case 'Kulkas':
                $hargaProduk = 3100000;
                break;
            case 'Mesin Cuci':
                $hargaProduk = 3800000;
                break;
        }

        $jumlahBeli = (int)$_POST['jumlah'];
        $total = $hargaProduk * $jumlahBeli;

        return number_format($total, 0, ',', '.');
    }

    return '';
}
?>
