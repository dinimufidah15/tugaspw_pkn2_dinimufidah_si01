<?php

//mendefinisikan variable
//$nama adalah nama variable
//rosalia indah adalah data dengan type string

$nama = 'Rosalia Indah';
$umur = 13;
$berat = 22.4;
//echo adalah menampilkan hasil
echo 'nama : '.$nama;
echo '<br>umur : '.$umur;
echo '<br>berat : '.$berat;
?>
<br>
<!-- ini adalah echo versi html -->
<?= $nama ?>