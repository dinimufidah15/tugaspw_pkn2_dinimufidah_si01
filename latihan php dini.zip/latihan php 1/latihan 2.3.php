<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<h1 align=center>form nilai</h1>
<form method="POST">
  <div class="form-group row">
    <label for="text" class="col-4 col-form-label">Nama</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-address-card"></i>
          </div>
        </div> 
        <input id="text" name="nama" type="text" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="select" class="col-4 col-form-label">matkul</label> 
    <div class="col-8">
      <select id="select" name="matkul" class="custom-select">
        <option value="ddp">ddp</option>
        <option value="basis data">basis data 1</option>
        <option value="pemweb 1">pemweb 1</option>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="text1" class="col-4 col-form-label">uts</label> 
    <div class="col-8">
      <input id="text1" name="uts" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="text2" class="col-4 col-form-label">uas</label> 
    <div class="col-8">
      <input id="text2" name="uas" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="text3" class="col-4 col-form-label">tugas</label> 
    <div class="col-8">
      <input id="text3" name="tugas" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="proses" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</form>

<?php
$grade = $predikat = $hasil ="";
if(isset($_POST['proses'])){
    $uts = $_POST['uts'];
    $uas = $_POST['uas'];
    $tugas = $_POST['tugas'];
    //hitung nilai kelulusan 30% uts 35% uas 35% tugas,55 == lulus
    $nilai_akhir = 0.3 * $uts + 0.35 * $uas + 0.35 * $tugas;
    if($nilai_akhir >= 55){
        $hasil = "lulus";
    } else {
        $hasil = "tidak lulus";
    }
    if ($nilai_akhir < 0 || $nilai_akhir > 100 ){
        $grade = "e";
    } else if ($nilai_akhir >= 85){
        $grade = "a";
    } else if ($nilai_akhir >= 70){
        $grade = "b";
    } else if ($nilai_akhir >= 56){
        $grade = "c";
    } else if ($nilai_akhir >= 36){
        $grade = "d";
    } else {
        $grade = "e";
    }
    switch($grade){
        case "a" : $predikat = "sangat sempurna"; break;
        case "b" : $predikat = "sempurna"; break;
        case "c" : $predikat = "cukup"; break;
        case "d" : $predikat = "kurang"; break;
        case "e" : $predikat = "sangat kurang"; break;
    }

echo "nama anda : " .$_POST['nama']. "<br>";
echo "mata kuliah : " .$_POST['matkul']. "<br>";
echo "uts : " .$_POST['uts']. "<br>";
echo "uas : " .$_POST['uas']. "<br>";
echo "tugas : " .$_POST['tugas']. "<br>";
echo "grade : " .$grade. "<br>";
echo "predikat : " .$predikat. "<br>";
echo "hasil : " .$hasil. "<br>";
echo "nilai akhir : " .$nilai_akhir;

}

?>