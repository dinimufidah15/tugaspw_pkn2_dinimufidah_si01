<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<h1 align=center>form nilai</h1>
<form method="GET">
  <div class="form-group row">
    <label for="text" class="col-4 col-form-label">nama</label> 
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-address-card"></i>
          </div>
        </div> 
        <input id="text" name="nama" type="text" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="select" class="col-4 col-form-label">matkul</label> 
    <div class="col-8">
      <select id="select" name="matkul" class="custom-select">
        <option value="ddp">ddp</option>
        <option value="basis data">basis data 1</option>
        <option value="pemweb 1">pemweb 1</option>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="text1" class="col-4 col-form-label">uts</label> 
    <div class="col-8">
      <input id="text1" name="uts" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="text2" class="col-4 col-form-label">uas</label> 
    <div class="col-8">
      <input id="text2" name="uas" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="text3" class="col-4 col-form-label">tugas</label> 
    <div class="col-8">
      <input id="text3" name="tugas" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="proses" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</form>
<?php
error_reporting(0);
//$PROSES ADALAH VARIABLE
//$_GET ADALAH METODE REQUEST
//['PROSES'] ADALAH NAME ATAU PENAMAAN SETIAP KOLOM INPUT
$proses = $_GET['proses'];
$nama = $_GET['nama'];
$matkul = $_GET['matkul'];
$uts = $_GET['uts'];
$uas = $_GET['uas'];
$tugas = $_GET['tugas'];
?>
nama siswa : <?= $nama ?>
<br> mata kuliah : <?= $matkul ?>
<br> nilai uts :<?= $uts ?>
<br> nilai uas :<?= $uas ?>
<br> nilai tugas: <?= $tugas ?>